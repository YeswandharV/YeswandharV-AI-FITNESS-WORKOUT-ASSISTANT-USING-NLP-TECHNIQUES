from django.contrib import admin
from Chatbot.models import Response

# Register your models here.
admin.site.register(Response)